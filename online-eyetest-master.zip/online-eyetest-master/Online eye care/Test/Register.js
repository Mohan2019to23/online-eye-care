function register(){
window.location = "Register.html"; // Redirecting to other page.
return false;
}
